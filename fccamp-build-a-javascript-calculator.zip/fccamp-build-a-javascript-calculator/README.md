# FCCamp: Build a Javascript Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/mkos11/pen/bGQRozb](https://codepen.io/mkos11/pen/bGQRozb).

"Basic Front End Development Projects" assignment from freeCodeCamp.com